<?php

return [
    'account_id' => env('SILVERAI_ACCOUNT_ID', 'd699eaca8e066e1bfaee9679eecb8fe1'),
    'gateway_id' => env('SILVERAI_GATEWAY_ID', 'silver-ai-hub'),
    'api_token' => env('SILVERAI_API_TOKEN', 'GpZ6dD-jPVIIN5vjDFizgJ9_aIFUFpVl0hwFmI45'),
];
